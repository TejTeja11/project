from django.contrib import admin
from admissions.models import Student

class StudentAdmin(admin.ModelAdmin):
    list_display=['id','name','firstname','classname','contact']

admin.site.register(Student,StudentAdmin)
# Register your models here.
