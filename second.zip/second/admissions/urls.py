from django.urls import path

from admissions.views import addAdmissions
from admissions.views import admissionsReport
from admissions.views import addVendor
from admissions.views import feecollection
from admissions.views import feecollectionreport
from admissions.views import studentresult
from admissions.views import studentresultreport
from admissions.views import deletestudent
from admissions.views import updatestudent
from admissions.views import FirstClassBasedView
from admissions.views import admissionsReportStudent


urlpatterns = [
    path('newadm/',addAdmissions),
    path('admreport/',admissionsReport),
    path('newvendor/',addVendor),
    path('feec/',feecollection),
    path('feecr/',feecollectionreport),
    path('str/',studentresult),
    path('strr/',studentresultreport),
    path('del/<int:id>',deletestudent),
    path('upd/<int:id>',updatestudent),
    path('admreports/',admissionsReportStudent),
    path('firstcls/',FirstClassBasedView.as_view()),
]
