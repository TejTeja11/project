from django.shortcuts import render
from admissions.models import Student
from admissions.forms import StudentModelForm
from admissions.forms import VendorForm
from django.http import HttpResponse
from django.views.generic import View
from django.contrib.auth.decorators import login_required
# Create your views here.
#function based views
@login_required
def homepage(request):
    return render(request,'index.html')
def logoutUser(request):
    return render(request,'logout.html')

@login_required
def addAdmissions(request):
    form=StudentModelForm
    studentform={'form':form}
    if request.method=='POST':
        form=StudentModelForm(request.POST)
        if form.is_valid():
            form.save()
        return homepage(request)
    return render(request,'admissions/add_admissions.html',studentform)

def admissionsReport(request):
    result=Student.objects.all()
    students={'allstudents':result}
    return render(request,'admissions/admissions_report.html',students)
def admissionsReportStudent(request):
    result=Student.objects.all()
    students={'allstudents':result}
    return render(request,'admissions/admissionstudent_report.html',students)

@login_required
def addVendor(request):
    form=VendorForm
    vform={'form':form}
    if request.method=='POST':
        form=VendorForm(request.POST)
        if form.is_valid():
            print(form.cleaned_data['name'])
            print(form.cleaned_data['address'])
            print(form.cleaned_data['contact'])
            print(form.cleaned_data['item'])
        return homepage(request)
    return render(request,'admissions/add-vendor.html',vform)

@login_required
def feecollection(request):
    return render(request,'admissions/fee_collection.html')

@login_required
def feecollectionreport(request):
    return render(request,'admissions/fee_collectionreport.html')

@login_required
def studentresult(request):
    return render(request,'admissions/student_result.html')

@login_required
def studentresultreport(request):
    return render(request,'admissions/student_resultreport.html')

@login_required
def deletestudent(request,id):
    s=Student.objects.get(id=id)
    s.delete()
    return admissionsReport(request)

@login_required
def updatestudent(request,id):
    s=Student.objects.get(id=id)
    form=StudentModelForm(instance=s)
    dict={'form':form}
    if request.method=='POST':
        form=StudentModelForm(request.POST,instance=s)
        if form.is_valid():
            form.save()
        return admissionsReport(request)
    return render(request,'admissions/update_student.html',dict)

class FirstClassBasedView(View):
    def get(self,request):
        return HttpResponse("hii")
