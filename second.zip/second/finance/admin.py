from django.contrib import admin
from finance.models import Teacher
class TeacherAdmin(admin.ModelAdmin):
    list_display=['id','name','department','contact','gmail']

# Register your models here.
admin.site.register(Teacher)
